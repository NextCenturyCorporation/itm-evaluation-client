# TriageCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_label** | **str** |  | [optional] 
**description** | **str** | a one-line description of the tagLabel category | [optional] 
**criteria** | **str** | detailed criteria for the tagLabel category | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

