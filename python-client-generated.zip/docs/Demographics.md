# Demographics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**age** | **int** | the age of the casualty, omit if unknown | [optional] 
**sex** | **str** | the sex of the casualty, omit if unknown/indeterminate | [optional] 
**rank** | **str** | The military status of the casualty, omit if unknown | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

